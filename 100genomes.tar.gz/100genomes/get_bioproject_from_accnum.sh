#!/bin/bash

for i in $(cat 100_accnum.csv); do $(esearch -db sra -query "$i" | efetch -format docsum | xtract -pattern DocumentSummary -element Bioproject >> 100_bioprj.txt); echo -e "$i"; done
