#!/bin/bash

for i in $(cat HOG_components.txt); 
	do
	filename="protein_seqs/$i.fa"
	touch "$filename"
	for k in $(cat 100_bioprj.txt);
		do (esearch -db protein -query "$i AND $k[Bioproject]" | \
		efetch -format fasta>>"$filename"); 
		echo -e "$i/$k";
	done; 
done

