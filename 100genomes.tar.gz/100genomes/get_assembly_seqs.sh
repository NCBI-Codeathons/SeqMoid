#!/bin/bash

for i in $(cat HOG_components.txt); 
	do
	filename="get_protein_ref/$i.fa"
	touch "$filename"
	(esearch -db protein -query "$i AND PRJNA43747[Bioproject]" | \
	efetch -format fasta>>"$filename"); 
	echo -e "$i";
	
done

