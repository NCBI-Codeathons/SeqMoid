#!/bin/bash

for i in $(cat HOG_components.txt);
	do
	fileout="blastp_output/$i.txt"
	touch "$fileout"
	file
	(blastp -db "blast_db/$i.fa"  -query "get_protein_ref/$i.fa" -out "$fileout" -outfmt "0");
	echo -e "$i";
done;
