#!/bin/bash

for i in $(cat HOG_components.txt);
        do
        filetemp="blast_db/$i.fa"
        touch "$filetemp"
        (makeblastdb -in "protein_seqs/$i.fa" -dbtype prot -out "$filetemp");
        echo -e "$i";
done;

