#!/bin/bash

for i in $(cat test.csv); 
	do for k in $(cat test_bioproj.txt);
		do (esearch -db protein -query "$i AND $k[Bioproject]" | \
		efetch -format fasta>>HOG_components.fa); 
		echo -e "$i/$k";
	done; 
done

